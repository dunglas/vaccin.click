# [vaccin.click](https://vaccin.click) : une extension Firefox pour trouver et réserver automatiquement votre créneau de vaccination COVID-19

Retrouvez toutes les infos concernant l'extension sur [vaccin.click](https://vaccin.click).

## Contribuer à l'extension

Voir [le guide publié par Mozilla](https://extensionworkshop.com/documentation/develop/).

## Crédits

Créé par [Kévin Dunglas](https://dunglas.fr) (licence AGPL).
[Icônes](https://www.iconfinder.com/icons/5959975/corona_drugs_injection_syringe_vaccine_icon) par [E Conceptive](https://www.iconfinder.com/econceptive) (licence Creative Commons Attribution 3.0 Unported).
